<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!--header-->
    <?php require_once 'header.php'; ?>
</body>
<?php
require 'mysqli.php'; // Asegúrate de que este archivo existe y tiene la conexión correcta a la base de datos

function sanitize_input($input) {
    return isset($input) ? htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8') : '';
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$titulo = sanitize_input($_POST['titulo'] ?? '');
$descripcion = sanitize_input($_POST['descripcion'] ?? '');
$estado = sanitize_input($_POST['estado'] ?? '');
$id_usuario = filter_input(INPUT_POST, 'id_usuario', FILTER_VALIDATE_INT);

if (!$id || !$titulo || !$id_usuario) {
    die("Datos inválidos.");
}

$stmt = $mysqli->prepare("UPDATE tareas SET titulo = ?, descripcion = ?, estado = ?, id_usuario = ? WHERE id = ?");
$stmt->bind_param("sssii", $titulo, $descripcion, $estado, $id_usuario, $id);

if ($stmt->execute()) {
    echo "Tarea actualizada correctamente.";
} else {
    echo "Error al actualizar la tarea: " . $stmt->error;
}

$stmt->close();
?>



   <!--footer-->
   <?php require_once 'footer.php'; ?>
</body>
</html>