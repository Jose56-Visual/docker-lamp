<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!--header-->
    <?php require_once 'header.php'; ?>
</body>
<?php
require 'pdo.php';

try {
    $stmt = $pdo->prepare('SELECT * FROM usuarios');
    $stmt->execute();
    $usuarios = $stmt->fetchAll();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

?>

<table>
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Nombre</th>
        <th>Apellidos</th>
        <th>Acciones</th>
    </tr>
    <?php foreach ($usuarios as $usuario): ?>
    <tr>
        <td><?php echo htmlspecialchars($usuario['id']); ?></td>
        <td><?php echo htmlspecialchars($usuario['username']); ?></td>
        <td><?php echo htmlspecialchars($usuario['nombre']); ?></td>
        <td><?php echo htmlspecialchars($usuario['apellidos']); ?></td>
        <td>
            <a href="editaUsuarioForm.php?id=<?php echo $usuario['id']; ?>">Editar</a>
            <a href="borraUsuario.php?id=<?php echo $usuario['id']; ?>">Borrar</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

   <!--footer-->
   <?php require_once 'footer.php'; ?>
</body>
</html>