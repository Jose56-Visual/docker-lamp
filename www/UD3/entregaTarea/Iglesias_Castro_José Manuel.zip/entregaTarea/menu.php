<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú</title>
</head>
<body>
<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
    <div class="position-sticky">
        <ul>
            <li><a href="index.php">Inicio</a></li>
            <li><a href="init.php">Inicializar aplicación</a></li> <!-- Opción para inicializar -->
            <li><a href="tareas.php">Lista de tareas</a></li>
            <li><a href="nuevaForm.php">Nueva tarea</a></li>
            <li><a href="usuarios.php">Lista de usuarios</a></li>
            <li><a href="nuevoUsuarioForm.php">Nuevo usuario</a></li>
        </ul>
    </div>
</nav> 