<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!--header-->
    <?php require_once 'header.php'; ?>
</body>
<!-- nuevaForm.php -->
<form action="nueva.php" method="POST">
    <label for="titulo">Título:</label>
    <input type="text" id="titulo" name="titulo" required><br>

    <label for="descripcion">Descripción:</label>
    <input type="text" id="descripcion" name="descripcion"><br>

    <label for="estado">Estado:</label>
    <input type="text" id="estado" name="estado"><br>

    <label for="id_usuario">Usuario:</label>
    <select id="id_usuario" name="id_usuario" required>
        <?php
        require 'pdo.php';
        $stmt = $pdo->prepare("SELECT id, username FROM usuarios");
        $stmt->execute();
        while ($usuario = $stmt->fetch()) {
            echo "<option value='" . htmlspecialchars($usuario['id']) . "'>" . htmlspecialchars($usuario['username']) . "</option>";
        }
        ?>
    </select><br>

    <input type="submit" value="Crear Tarea">
</form>

   <!--footer-->
   <?php require_once 'footer.php'; ?>
</body>
</html>