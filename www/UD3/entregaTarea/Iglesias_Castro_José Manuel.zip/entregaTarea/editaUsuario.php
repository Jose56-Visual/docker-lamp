<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!--header-->
    <?php require_once 'header.php'; ?>
</body>
<?php
require 'pdo.php';

function sanitize_input($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
$username = sanitize_input($_POST['username']);
$nombre = sanitize_input($_POST['nombre']);
$apellidos = sanitize_input($_POST['apellidos']);
$contrasena = !empty($_POST['contrasena']) ? password_hash($_POST['contrasena'], PASSWORD_DEFAULT) : null;

if (!$id || !$username) {
    die("Datos inválidos.");
}

try {
    $sql = "UPDATE usuarios SET username = :username, nombre = :nombre, apellidos = :apellidos";
    if ($contrasena) {
        $sql .= ", contrasena = :contrasena";
    }
    $sql .= " WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':nombre', $nombre);
    $stmt->bindParam(':apellidos', $apellidos);
    if ($contrasena) {
        $stmt->bindParam(':contrasena', $contrasena);
    }
    if ($stmt->execute()) {
        echo "Usuario actualizado correctamente.";
    } else {
        echo "Error al actualizar el usuario.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>


   <!--footer-->
   <?php require_once 'footer.php'; ?>
</body>
</html>