<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!--header-->
    <?php require_once 'header.php'; ?>
</body>
<?php
require 'mysqli.php';

// Verificar conexión y selección de base de datos
if ($mysqli->select_db("tareas")) {
    echo "Base de datos seleccionada correctamente.<br>";
} else {
    echo "Error al seleccionar la base de datos: " . $mysqli->error . "<br>";
}

// Verificar existencia de la tabla
$result = $mysqli->query("SHOW TABLES LIKE 'tareas'");
if ($result->num_rows > 0) {
    echo "Tabla 'tareas' encontrada.<br>";
} else {
    echo "Tabla 'tareas' no encontrada.<br>";
}

// Ejecutar consulta de tareas
$result = $mysqli->query("SELECT tareas.id, tareas.titulo, tareas.descripcion, tareas.estado, usuarios.username
                          FROM tareas
                          JOIN usuarios ON tareas.id_usuario = usuarios.id");

if (!$result) {
    die("Error en la consulta: " . $mysqli->error);
}
?>

<table>
    <tr>
        <th>ID</th>
        <th>Título</th>
        <th>Descripción</th>
        <th>Estado</th>
        <th>Usuario</th>
        <th>Acciones</th>
    </tr>
    <?php while ($tarea = $result->fetch_assoc()): ?>
    <tr>
        <td><?php echo htmlspecialchars($tarea['id']); ?></td>
        <td><?php echo htmlspecialchars($tarea['titulo']); ?></td>
        <td><?php echo htmlspecialchars($tarea['descripcion']); ?></td>
        <td><?php echo htmlspecialchars($tarea['estado']); ?></td>
        <td><?php echo htmlspecialchars($tarea['username']); ?></td>
        <td>
            <a href="editaTareaForm.php?id=<?php echo $tarea['id']; ?>">Editar</a>
            <a href="borraTarea.php?id=<?php echo $tarea['id']; ?>">Borrar</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
   <!--footer-->
   <?php require_once 'footer.php'; ?>
</body>
</html>