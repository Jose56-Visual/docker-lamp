<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!--header-->
    <?php require_once 'header.php'; ?>
</body>
<form action="tareas.php" method="GET">
    <label for="usuario">Usuario:</label>
    <select id="usuario" name="usuario" required>
        <?php
        require 'pdo.php';
        $stmt = $pdo->prepare("SELECT id, username FROM usuarios");
        $stmt->execute();
        while ($usuario = $stmt->fetch()) {
            echo "<option value='" . htmlspecialchars($usuario['id']) . "'>" . htmlspecialchars($usuario['username']) . "</option>";
        }
        ?>
    </select><br>

    <label for="estado">Estado (opcional):</label>
    <input type="text" id="estado" name="estado"><br>

    <input type="submit" value="Buscar Tareas">
</form>
