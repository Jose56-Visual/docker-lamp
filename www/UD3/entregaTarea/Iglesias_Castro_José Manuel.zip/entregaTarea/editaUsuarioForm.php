<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <!--header-->
    <?php require_once 'header.php'; ?>
</body>
<?php
require 'pdo.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    die("ID de usuario inválido.");
}

try {
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = :id");
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $usuario = $stmt->fetch();
    if (!$usuario) {
        die("Usuario no encontrado.");
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

?>

<form action="editaUsuario.php" method="POST">
    <input type="hidden" name="id" value="<?php echo htmlspecialchars($usuario['id']); ?>">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($usuario['username']); ?>" required><br>

    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($usuario['nombre']); ?>"><br>

    <label for="apellidos">Apellidos:</label>
    <input type="text" id="apellidos" name="apellidos" value="<?php echo htmlspecialchars($usuario['apellidos']); ?>"><br>

    <label for="contrasena">Nueva contraseña:</label>
    <input type="password" id="contrasena" name="contrasena"><br>

    <input type="submit" value="Actualizar Usuario">
</form>

   <!--footer-->
   <?php require_once 'footer.php'; ?>
</body>
</html>