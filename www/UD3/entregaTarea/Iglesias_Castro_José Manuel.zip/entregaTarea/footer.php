<footer class="bg-dark text-white text-center py-3">
    <p class="small">&copy; 2024 Jose Manuel Iglesias Castro - Todos los derechos reservados.</p>
</footer>