<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú</title>
</head>
<body>
<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
    <div class="position-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    Inicio
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="listaTareas.php">
                    Mis Tareas
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="nuevaForm.php">
                    Nueva Tarea
                </a>
            </li>
        </ul>
    </div>
</nav> 